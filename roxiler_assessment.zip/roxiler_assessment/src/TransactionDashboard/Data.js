const data = [{
    id: 1,
    title: 'Product 1',
    description: 'This is a description for the first product.',
    price: 29.99,
    category: 'Electronics',
    sold: 'true',
    image: 'https://via.placeholder.com/150', // Placeholder image
  },
  {
    id: 2,
    title: 'Product 2',
    description: 'This is a description for the second product.',
    price: 19.95,
    category: 'Clothing',
    sold: 'false',
    image: 'https://via.placeholder.com/150', // Placeholder image
  },
];
export default data;