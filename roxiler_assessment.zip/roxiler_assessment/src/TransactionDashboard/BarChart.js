import React, { useState, useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

const BarChart = ({ labels, datasets }) => {
  const chartRef = useRef(null);

  useEffect(() => {
    if (chartRef.current) {
      const ctx = chartRef.current.getContext('2d');
      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [{
            label: 'Number of Items',
            data: datasets,
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1,
          }],
        },
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });
    }
  }, [labels, datasets]);

  return (
    <div>
      <h2>Bar Chart</h2>
      <canvas ref={chartRef}></canvas>
    </div>
  );
};

export default BarChart;
