import React, { useState, useEffect } from 'react'
import data from './Data';
import './DashboardTable.css'
import { MagnifyingGlass } from 'phosphor-react';
import BarChart from './BarChart'; // Assuming the BarChart component file is in the same directory

const DashboardTable = () => {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [month, setMonth] = useState('March');
  const [totalPage, setTotalPage] = useState(0);
  const perPage = 10;

  // State to store fetched data
  const [transactions, setTransactions] = useState([]);
  //const [barChartData, setBarChartData] = useState({});
  let barChartData = {}
  const [salesStatistics, setSalesStatistics] = useState({});
  let monthNum = 3;

  useEffect(() => {
    fetchTransactions();
    fetchSalesStatistics();
    fetchBarChart();
  }, [search, page, month]); // Re-fetch on state changes
  

  async function fetchTransactions() {
    try {
      const response = await fetch(
        `http://localhost:5000/transactions?page=${page}&perPage=${perPage}&search=${search}&month=${month}`
      );
  
      if (!response.ok) {
        throw new Error('Failed to fetch transactions');
      }
  
      const jsonData = await response.json(); // Extract JSON data from response
      console.log(jsonData);
      setTransactions(jsonData.data); // Update state with fetched data
    } catch (error) {
      console.error('Error fetching transactions:', error);
    }
  }

  async function fetchSalesStatistics() {
    try {
      if(month === 'January' ) monthNum = 1; else if(month === 'Feburary' ) monthNum = 2; else if(month === 'March' ) monthNum = 3; else if(month === 'April' ) monthNum = 4; else if(month === 'May' ) monthNum = 5; else if(month === 'June' ) monthNum = 6; else if(month === 'July' ) monthNum = 7; else if(month === 'August' ) monthNum = 8; else if(month === 'September' ) monthNum = 9; else if(month === 'October' ) monthNum = 10; else if(month === 'November' ) monthNum = 11;  else if(month === 'December' ) monthNum = 12; 
      const response = await fetch(`http://localhost:5000/sales-statistics?month=${monthNum}`);

      if (!response.ok) {
        throw new Error('Failed to fetch sales statistics');
      }

      const data = await response.json();

      if (!data) {
        // Handle no data found case (optional)
        console.log('No sales statistics found for the month');
      } else {
        setSalesStatistics(data);
      }
    } catch (error) {
      console.error('Error fetching sales statistics:', error);
    }
  }


  async function fetchBarChart() {
    try {
      if(month === 'January' ) monthNum = 1; else if(month === 'Feburary' ) monthNum = 2; else if(month === 'March' ) monthNum = 3; else if(month === 'April' ) monthNum = 4; else if(month === 'May' ) monthNum = 5; else if(month === 'June' ) monthNum = 6; else if(month === 'July' ) monthNum = 7; else if(month === 'August' ) monthNum = 8; else if(month === 'September' ) monthNum = 9; else if(month === 'October' ) monthNum = 10; else if(month === 'November' ) monthNum = 11;  else if(month === 'December' ) monthNum = 12; 
      const response = await fetch(`http://localhost:5000/bar-chart-data?month=${monthNum}`);
  
      if (!response.ok) {
        throw new Error('Failed to fetch bar chart data');
      }
  
      const data = await response.json();
  
      if (!data) {
        console.log('No bar chart data found for the month');
        // Consider handling the case of no data gracefully on the frontend (e.g., display a chart with no data)
      } else {
        // Process data for chart library
        console.log(data)
        const chartData = {
          labels: data.labels,
          datasets: [
            {
              label: 'Number of Items',
              data: data.datasets,
              backgroundColor: 'rgba(54, 162, 235, 0.2)',
              borderColor: 'rgba(54, 162, 235, 1)',
              borderWidth: 1,
            },
          ],
        };
        console.log("!",chartData.labels[0])
        // Chart configuration
        const chartConfig = {
          type: 'bar', // Or 'line', 'pie', etc. based on your preference
          data: chartData,
          options: {
            scales: {
              yAxes: [
                {
                  ticks: {
                    beginAtZero: true,
                  },
                },
              ],
            },
          },
        };
        console.log("1", chartConfig);
       // setBarChartData(chartConfig); // Update state with chart configuration
       barChartData = data
        console.log("2", barChartData); // For debugging purposes
      }
    } catch (error) {
      console.error('Error fetching bar chart data:', error);
    }
  }


    const months = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December',
      ];

  return (
    <div className='transaction-dashboard'>
      <div className='transaction-dashboard-circle'>
        <h2>Transaction Dashboard</h2>
      </div>

      <div className='transaction-dashboard-search'>
        
        <div className='transaction-dashboard-search-tab'>
          <input type='text' placeholder='Search Transaction' className='transaction-dashboard-search-bar' 
            onChange={(e)=>{
              setSearch(e.target.value);
            }}
          />
          <button className='transaction-dashboard-search-btn' onClick={()=>fetchTransactions()}><MagnifyingGlass size={16} weight="bold" /></button>
        </div>


        <select id="month-dropdown" className='transaction-dashboard-search-dd' onChange={(e)=>{setMonth(e.target.value)}}>
            <option value="">Select Month</option>
            {months.map((month, index) => (
                <option key={index} value={month} className='transaction-dashboard-search-dd-options'>
                {month}
                </option>
            ))}
        </select>
      </div>

      <div className='transaction-dashboard-search-table-div'>
        <table className='transaction-dashboard-search-table'>
          <tr className='transaction-dashboard-search-table-tr'>
            <th style={{width: '50px', borderLeft: '0px'}} className='transaction-dashboard-search-table-th'>ID</th>
            <th style={{width: '200px'}} className='transaction-dashboard-search-table-th'>Title</th>
            <th style={{width: '280px'}} className='transaction-dashboard-search-table-th'>Description</th>
            <th style={{width: '60px'}} className='transaction-dashboard-search-table-th'>Price</th>
            <th style={{width: '100px'}} className='transaction-dashboard-search-table-th'>Category</th>
            <th style={{width: '80px'}} className='transaction-dashboard-search-table-th'>Sold</th>
            <th style={{width: '100px'}} className='transaction-dashboard-search-table-th'>Image</th>
          </tr>
          {transactions.map((transaction, index) => (
            // <tr key={transaction.id || index} style={{height: '40px'}}>
            //   {Object.keys(transaction).map((field, index) => (
            //     <td
            //       key={index}
            //       className={field === 'id' ? 'transaction-dashboard-search-table-td-no-border' : 'transaction-dashboard-search-table-td'}
            //     >
            //       {transaction[field]}
            //     </td>
            //   ))}
            // </tr>
            <tr className='transaction-dashboard-search-table-tr'>
            <th style={{width: '50px', borderLeft: '0px'}} className='transaction-dashboard-search-table-td'>{transaction.id}</th>
            <th style={{width: '200px'}} className='transaction-dashboard-search-table-td'>{transaction.title}</th>
            <th style={{width: '280px'}} className='transaction-dashboard-search-table-td'>{transaction.description}</th>
            <th style={{width: '60px'}} className='transaction-dashboard-search-table-td'>{transaction.price}</th>
            <th style={{width: '100px'}} className='transaction-dashboard-search-table-td'>{transaction.category}</th>
            <th style={{width: '80px'}} className='transaction-dashboard-search-table-td'>{transaction.sold}</th>
            <th style={{width: '10px'}} className='transaction-dashboard-search-table-td'><img alt='images' src={transaction.image} height={100} width={100} /></th>
          </tr>
          ))}
        </table>
      </div>

      <div className='transaction-dashboard-pagination'>
          <p>Page No.: {page}</p>

          <div style={{marginTop: '17px'}}>
            <button className='transaction-dashboard-pagination-btn' onClick={()=>{page> 1? setPage(page-1) : setPage(page); fetchTransactions()}}><b>Previous</b></button>&nbsp;&nbsp; - &nbsp;&nbsp;
            <button className='transaction-dashboard-pagination-btn' onClick={()=>{setPage(page+1); fetchTransactions()}}><b>Next</b></button>
          </div>
          <p>Per Page: 10</p>
        </div>

        <div className='transaction-dashboard-statistics'>
          <h2>Statistics - {month}</h2>

          <div className='transaction-dashboard-statistics-data'>
            <h3><pre>Total Sale            {salesStatistics.total_sale_amount}</pre></h3>
            <h3><pre>Total Sold Item       {salesStatistics.sold_items}</pre></h3>
            <h3><pre>Total Unsold Items    {salesStatistics.unsold_items}</pre></h3>
          </div>
        </div>
          
      <div className='transaction-dashboard-bar-chart'>
        <BarChart labels={barChartData.labels} datasets={barChartData.datasets} />
      </div>

    </div>
  )
}

export default DashboardTable;