import React from 'react';
import DashboardTable from './TransactionDashboard/DashboardTable'
import './App.css';

function App() {
  return (
    <div className="App">
      <DashboardTable />
    </div>
  );
}

export default App;
