// const express = require('express');
// const mysql = require('mysql');
// const axios = require('axios');
// const cors = require('cors'); // Import cors middleware

// // Replace with your connection details
// const connection = mysql.createConnection({
//   host: 'sql12.freemysqlhosting.net',
//   user: 'sql12713248',
//   password: 'HTrFw66qQJ',
//   database: 'sql12713248'
// });

// const app = express();
// const port = process.env.PORT || 5000;

// // CORS middleware (add this before route definitions)
// app.use(cors());

// // Connect to the database (remains the same)
// connection.connect((err) => {
//   if (err) {
//     console.error('Error connecting to database:', err);
//     process.exit(1);
//   }
//   console.log('Connected to database');
// });

// // Seed data endpoint
// app.get('/api/v1/seed-data', async (req, res) => {
//   try {
//     // Fetch data from JSON URL
//     const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
//     const data = response.data;

//     // Loop through data and insert into database
//     for (const row of data) {
//       const query = `INSERT INTO roxiler (id, title, description, price, category, sold, imageURL) VALUES (?, ?, ?, ?, ?, ?, ?)`;
//       const values = [row.id, row.title, row.description, row.price, row.category, row.sold, row.image];

//       connection.query(query, values, (error, result) => {
//         if (error) {
//           console.error('Error inserting data:', error);
//           return;
//         }
//       });
//     }

//     res.json({ message: 'Data seeding completed successfully' });
//   } catch (error) {
//     console.error('Error fetching or seeding data:', error);
//     res.status(500).json({ message: 'Failed to seed data' });
//   }
// });

// // Start the server
// app.listen(port, () => {
//   console.log(`Server listening on port ${port}`);
// });


const mysql = require('mysql');

const connection = mysql.createConnection({
  host: 'sql12.freemysqlhosting.net',
  user: 'sql12713248',
  password: 'HTrFw66qQJ',
  database: 'sql12713248'
});

module.exports = connection;
