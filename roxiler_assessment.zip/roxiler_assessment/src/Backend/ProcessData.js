

function processFetchedData(fetchedData) {
    const formattedData = fetchedData.map(transaction => ({
        id: transaction.id,
        title: transaction.title,
        description: transaction.description,
        price: transaction.price,
        category: transaction.category.toLowerCase(),
        sold: transaction.sold === 0 ? 'false' : 'true',
        image: transaction.imageURL // Assuming imageURL exists in the database
      }));
      return formattedData;
}

module.exports = { processFetchedData };