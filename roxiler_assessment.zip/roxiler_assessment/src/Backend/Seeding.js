const axios = require('axios');
const connection = require('./Config'); // Import connection

async function seedData() {
    try {
        // Fetch data from JSON URL
        const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
        const data = response.data;

        // Loop through data and insert into database
        for (const row of data) {
            const query = `INSERT INTO roxiler (id, title, description, price, category, sold, imageURL, dateofsale) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
            const values = [row.id, row.title, row.description, row.price, row.category, row.sold, row.image, row.dateOfSale];

            connection.query(query, values, (error, result) => {
                if (error) {
                    console.error('Error inserting data:', error);
                    return;
                }
            });
        }

        // res.json({ message: 'Data seeding completed successfully' });
    } catch (error) {
        console.error('Error fetching or seeding data:', error);
        // res.status(500).json({ message: 'Failed to seed data' });
    }
}

module.exports = { seedData }; // Export the function
