const express = require('express');
const transactions = require('./Transactions'); // Assuming this handles data processing
const connection = require('./Config'); // Assuming this establishes the database connection
const cors = require('cors')
const seeder = require('./Seeding')
const bodyParser = require('body-parser');

const app = express();
const port = process.env.PORT || 5000;

// Default pagination values

app.use(cors({ origin: '*' }));
app.use(bodyParser.json())


//seeder.seedData();

//For Table

app.get('/transactions', (req, res) => {
  const DEFAULT_PAGE = 1;
  const DEFAULT_PER_PAGE = 10;
  const search = req.query.search || ''; // Get search query parameter (optional)
  const page = parseInt(req.query.page) || DEFAULT_PAGE; // Get page number (optional)
  const perPage = parseInt(req.query.per_page) || DEFAULT_PER_PAGE; // Get per page limit (optional)

  transactions.fetchData(search, page, perPage, (error, data) => {
    if (error) {
      console.error('Error fetching data:', error);
      res.status(500).json({ message: 'Error fetching transactions' });
      return;
    }

    res.json({ data, total: data.length }); // Send response data and total count
    //console.log(data);
  });
});

//for statistics
app.get('/sales-statistics', async (req, res) => {
  const { month } = req.query; // Get the month from the query parameter
  console.log(month);
  if (!month) {
    return res.status(400).json({ message: 'Missing required parameter: month' });
  }

  try {
    const sql = `
      SELECT 
        SUM(price) AS total_sale_amount,
        COUNT(*) AS total_items,
        SUM(CASE WHEN sold = TRUE THEN 1 ELSE 0 END) AS sold_items,
        SUM(CASE WHEN sold = FALSE THEN 1 ELSE 0 END) AS unsold_items
      FROM roxiler
      WHERE MONTH(dateofsale) = ?
    `;
    //console.log('hello')
    await connection.query(sql, [month], (error, rows) => {

    if (!rows.length) {
      return res.status(404).json({ message: 'No data found for the provided month' });
    }
    
    //console.log(rows[0]);
    res.json(rows[0]); // Return the first row containing the statistics
  })
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.get('/bar-chart-data', async (req, res) => {
  const { month } = req.query; // Get the month from the query parameter
  console.log(month);
  if (!month) {
    return res.status(400).json({ message: 'Missing required parameter: month' });
  }

  try {
    const sql = `
      SELECT
        FLOOR(price / 100) * 100 AS price_range,
        COUNT(*) AS num_items
      FROM roxiler
      WHERE MONTH(dateofsale) = ?
      GROUP BY FLOOR(price / 100) * 100
      ORDER BY price_range ASC;
    `;

    await connection.query(sql, [month],  (error, rows) => {
      if (!rows.length) {
      return res.status(404).json({ message: 'No data found for the provided month' });
    }

    const barChartData = {
      labels: rows.map(row => `$${row.price_range} - $${row.price_range + 99}`),
      datasets: [{
        data: rows.map(row => row.num_items),
        backgroundColor: ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4CAF50', '#8BC34A'],
        borderColor: ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4CAF50', '#8BC34A'],
        borderWidth: 1
      }]
    };

    console.log(barChartData);
    res.json(barChartData);
  });

    
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
});



app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
