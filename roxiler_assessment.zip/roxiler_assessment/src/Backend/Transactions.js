const connection = require('./Config'); // Import connection
const processData = require('./ProcessData');

const DEFAULT_PAGE = 1;
const DEFAULT_PER_PAGE = 10;

function fetchData(search, page = DEFAULT_PAGE, perPage = DEFAULT_PER_PAGE, callback) {
  const offset = (page - 1) * perPage; // Calculate offset for pagination

  let query = 'SELECT * FROM roxiler';
  const queryParams = []; // Array to hold query parameters

  if (search) {
    query += ' WHERE (title LIKE ? OR description LIKE ? OR price LIKE ?)';
    queryParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }

  query += ' LIMIT ?, ?';
  queryParams.push(offset, perPage);

  connection.query(query, queryParams, (error, rows) => {
    if (error) {
      callback(error, null);
      return; // Exit the function if there's an error
    }

    const formattedData = processData.processFetchedData(rows);
    //console.log(formattedData);
    callback(null, formattedData); // Pass results (rows) or null on error
  });
}

module.exports = { fetchData }; // Export the function
